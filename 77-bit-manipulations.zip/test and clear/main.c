#include<stdio.h>
int main(){
    int bit,clear,num,pos;
    printf("enter the number ");
    scanf("%d",&num);
    
    printf("select the position to test and clear ");
    scanf("%d",&pos);
    
    bit=num & (1 << pos);
    printf("position of bit is %d ",bit);
    
    clear=num & ~(1 << pos);
    printf("after clear bit number is %d",clear);
    return 0;
}