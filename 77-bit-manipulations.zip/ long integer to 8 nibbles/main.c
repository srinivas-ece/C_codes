#include<stdio.h>
int main(){
    long int num;
    int nibble[8];
    printf("enter the long int");
    scanf("%lu",&num);
    
    for(int i=0; i<8; i++){
        nibble[i]=num & 0xf;
        num=num >> 4;
    }
    
    printf("\nNibbles :");
    for (int i = 7; i >= 0; i--) {
        printf("%X ", nibble[i]);
    }
    return 0;
}