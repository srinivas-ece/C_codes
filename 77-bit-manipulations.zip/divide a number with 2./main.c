#include<stdio.h>
int main(){
    int num,division;
    printf("enter the number ");
    scanf("%d",&num);
    printf("before division %b\n",num);
    
    division = (num >> 1);
    printf("after division %d\nbinary %b",division,division);
    return 0;
}