#include<stdio.h>
int main(){
    int num,n,rev=0;
    
    printf("enter the number ");
    scanf("%d",&num);
    
    n=num;
    printf("number is %d",n);
    
    while(num>0){
        int bit = num & 1;
        
        rev = (rev << 1) | bit;
        
        num = num >> 1;
        
    }
    
    printf(" reverse number %d",rev);
    return 0;
}