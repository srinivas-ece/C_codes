#include<stdio.h>
int main(){
    int j=0,i,num,bit,binary[30];
    
    printf("enter the number ");
    scanf("%d",&num);
    
    while(num>0){
        bit=num%2;
        num=num/2;
        binary[j]=bit;
        j++;    
    }
    for(i=j-1; i>=0; i--){
        printf("%d",binary[i]);
    }
    
    return 0;
}