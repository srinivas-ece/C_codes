#include<stdio.h>
int main(){
    int num,data;
    
    printf("enter the number ");
    scanf("%d",&num);
    
    data = num & 1;
    
    if(data == 0){
        printf("it is even number ");
    }
    else{
        printf("it is a odd number ");
    }
        return 0;
    
}