#include<stdio.h>
int main(){
    int num;
    printf("enter the number");
    scanf("%d",&num);
    
    printf("binary %d num is %b :",num,num);
    
    return 0;
    
}
