#include<stdio.h>
int main(){
    int num,n;
    printf("enter the number ");
    scanf("%d",&num);
    
    printf("enter the bit position to test and set ");
    scanf("%d",&n);
    
    int bitplace = num & (1 << n);
    
    printf("testing bit %d\n",bitplace);
    
    num=num | (1<<n);
    printf("After setting: Number = %d\n", num);
    
    return 0;
}