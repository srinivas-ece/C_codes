#include<stdio.h>
int main(){
    int a,b;
    printf("enter the a value ");
    scanf("%d",&a);
    
    printf("enter the b value ");
    scanf("%d",&b);

    printf("before swap \na=%d b=%d",a,b);
    
    a=a ^ b;
  
    b=a ^ b;
   
    a=a ^ b;
   
    
    printf("\nafter swap \na=%d b=%d",a,b);
    return 0;
    
}