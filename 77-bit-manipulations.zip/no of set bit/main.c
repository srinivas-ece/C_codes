#include<stdio.h>
int main(){
    int num,i,count=0,bit;
    
    printf("enter the integer ");
    scanf("%d",&num);
    
    while(num>0){
        bit=num%2;
        num=num/2;
        if(bit==1){
        count++;
      
        }
    }
       
    
    printf("%d",count);
    return 0;
    
}